
For complete licensing information, visit:
https://fullcalendar.io/license

FullCalendar Premium is tri-licensed, meaning you must choose
one of three licenses to use. Here is a summary of those licenses:

- Commercial License
  (a paid license, intended for commercial use)
  https://fullcalendar.io/commercial-license

- Creative Commons Non-Commercial No-Derivatives
  (intended for trial and non-commercial use)
  https://creativecommons.org/licenses/by-nc-nd/4.0/

- GPLv3 License
  (intended for open-source projects)
  http://www.gnu.org/licenses/gpl-3.0.en.html
